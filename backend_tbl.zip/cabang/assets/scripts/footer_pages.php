	<div class="app-wrapper-footer">
		<div class="app-footer">
			<div class="">
				<div class="app-footer__inner">
					<div class="app-footer-left">
						<div class="footer-dots">
							<div class="dropdown">
								<span class="dot-btn-wrapper footer_copyright">
									<span>Copyright</span> &copy; <?php echo date("Y");?> 
									<?php echo $nama_perusahaan['nama_website'];?>&nbsp;<span>- <?php echo $tagline['tagline'];?></span>
								</span>
							</div>
							<div class="dots-separator"></div>
							<div class="dropdown">
								<a class="dot-btn-wrapper dd-chart-btn-2 footer_version" aria-haspopup="true" data-toggle="dropdown" aria-expanded="false">
									<strong>version</strong>&nbsp;3.0
								</a>
								<div tabindex="-1" role="menu" aria-hidden="true" class="dropdown-menu-xl rm-pointers dropdown-menu hide">
									<ul class="nav flex-column">
										<li class="nav-item-btn text-center nav-item">
											<button class="btn-shine btn-wide btn-pill btn btn-warning btn-sm footer_version_detail">
												<i class="fa fa-cog fa-spin mr-2"></i>
												January 2021
											</button>
										</li>
									</ul>
								</div>
							</div>

						</div>
					</div>
					<div class="app-footer-right">
						<ul class="header-megamenu nav">
							<li class="nav-item">
								<a href="#" id="to_top" class="nav-link">
									<div class="badge badge-primary ml-0 ml-1">
										<small>Back to Top <i class="fa fa-angle-up"></i></small>
									</div>
								</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>