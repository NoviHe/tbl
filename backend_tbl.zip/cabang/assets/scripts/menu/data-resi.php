	<div class="app-inner-layout__sidebar">
		<div class="app-layout__sidebar-inner dropdown-menu-rounded">
			<div class="nav flex-column">
				<div class="nav-item-header text-primary nav-item second_menu">
					Data Resi
				</div>
				<a class="dropdown-item second_menu_link otomatis-actives" href="resi-otomatis">Resi Otomatis</a>
				<a class="dropdown-item second_menu_link manual-actives" href="resi-manual">Resi Manual</a>
				<a class="dropdown-item second_menu_link tujuan_tarif-actives" href="tujuan-tarif">Tujuan &amp; Tarif</a>
				<a class="dropdown-item second_menu_link marketing-actives" href="marketing">Marketing</a>
				
				<!--
				<a class="dropdown-item second_menu_link aaaaaaaaa-actives" href="aaaaaaaaa">aaaaaaaaa</a>
				-->
			</div>                            
		</div>
	</div>