	<style>
		.slimScrollBar {
			display: none!important;
		}
	</style>
	<aside class="main-sidebar">
		<section class="sidebar">		
			<ul class="sidebar-menu" data-widget="tree">
				<li class="header">
					<img src="../.core/.assets/.img/logo-tbl-white.png" style="margin-top:200%; width:100px;">
				</li>
				<li class="header">
					TBL
				</li>
			</ul>
		</section>
	</aside>