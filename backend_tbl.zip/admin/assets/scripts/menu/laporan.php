	<div class="app-inner-layout__sidebar">
		<div class="app-layout__sidebar-inner dropdown-menu-rounded">
			<div class="nav flex-column">
				<div class="nav-item-header text-primary nav-item second_menu">
					Laporan
				</div>
				<a class="dropdown-item second_menu_link keuangan-actives" href="laporan-pemasukan">laporan keuangan</a>
				<a class="dropdown-item second_menu_link absensi-actives" href="laporan-absensi">laporan absensi</a>
			</div>                            
		</div>
	</div>