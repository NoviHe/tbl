Anda akan menghapus secara permanen data ini dari situs Anda
<br>
<strong>
	Tindakan Ini Tidak Dapat Dikembalikan!
</strong>
<br>
"Cancel Untuk Membatalkan" atau "Delete Untuk Menghapus".